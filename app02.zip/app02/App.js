import * as React from 'react';
import {View,Text,StyleSheet,Image,ScrollView} from 'react-native';

export default function App(){
  return(
    <View style={estilo.container}>
      <Text style={estilo.titulo}> Praias Lindas do Brasil </Text>
      <Text style={estilo.frase}> Férias do Silvão... </Text>
      <ScrollView style={estilo.fotos}>
      <Image style={estilo.img} source={require("./assets/beach-g94e013551_640.jpg")}/>
      <Text style={estilo.legenda}> Praia 1... </Text>
      <Image style={estilo.img} source={require("./assets/beach-g4610b4668_640.jpg")}/>
      <Text style={estilo.legenda}> Praia 2... </Text>
      <Image style={estilo.img} source={require("./assets/pesada.jpg")}/>
      <Text style={estilo.legenda}> Praia 3... </Text>
      <Image style={estilo.img} source={require("./assets/maldives-g28ef1ae9c_640.jpg")}/>
      </ScrollView>
      </View>
  );
}

const estilo = StyleSheet.create({
container:{
flex:1,
alignItems:'center',
backgroundColor:'#48D1CC',

},
titulo:{
fontWeight:'bold',
textAlign:'center',
fontSize:30,
marginTop: 45,
marginBotton:20,

},
frase:{
fontSize: 15,
marginBotton:20,
textAlign:'center'

},
img:{
width:300,
height:200,

},
legenda:{
textAlign:'center',
fontFamily:'monospace',

},
fotos:{
alignItems:'center',

}

});
